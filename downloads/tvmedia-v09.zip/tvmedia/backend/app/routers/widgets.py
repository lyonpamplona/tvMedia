"""Proxy de widgets dinamicos (noticias via RSS) para o player.

O player roda sem autenticacao e, por restricao de CORS, nao consegue buscar
feeds RSS de outros dominios diretamente no navegador. Este roteador busca os
feeds no servidor e devolve um JSON normalizado de manchetes. O widget de clima
e obtido client-side (open-meteo, sem chave), portanto nao precisa de proxy.

A rota e publica (como o /api/display/{slug}) para que o player possa consumi-la
sem token. So aceita esquemas http/https e impoe timeout e limite de tamanho.
"""

from __future__ import annotations

import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

from fastapi import APIRouter, Query

router = APIRouter(prefix="/api/widgets", tags=["widgets"])

_TIMEOUT = 6
_USER_AGENT = "tvMedia/1.0"
_MAX_PER_FEED = 15
_MAX_BYTES = 1_000_000
_MAX_FEEDS = 6


def _fetch(url: str) -> str:
    """Baixa o conteudo de um feed com timeout e limite de bytes."""
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:  # noqa: S310
        raw = resp.read(_MAX_BYTES)
    return raw.decode("utf-8", errors="replace")


def _clean(text: str | None) -> str:
    """Normaliza espacos em branco de um texto."""
    if not text:
        return ""
    return " ".join(text.split()).strip()


def _parse_feed(xml_text: str) -> list[dict]:
    """Extrai titulos/links de um feed RSS 2.0 ou Atom (tolerante a namespaces)."""
    items: list[dict] = []
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return items
    for node in root.iter():
        tag = node.tag.lower()
        if not (tag.endswith("item") or tag.endswith("entry")):
            continue
        title = None
        link = None
        for child in node:
            ctag = child.tag.lower()
            if ctag.endswith("title") and title is None:
                title = child.text
            elif ctag.endswith("link") and link is None:
                link = child.text or child.attrib.get("href")
        if title:
            items.append({"title": _clean(title), "link": _clean(link)})
        if len(items) >= _MAX_PER_FEED:
            break
    return items


@router.get("/news")
def news(
    feeds: str = Query("", description="URLs de feeds RSS separadas por virgula."),
    limit: int = Query(20, ge=1, le=60),
) -> dict:
    """Agrega manchetes de um ou mais feeds RSS/Atom (uso publico pelo player)."""
    urls = [u.strip() for u in feeds.split(",") if u.strip()]
    headlines: list[dict] = []
    for url in urls[:_MAX_FEEDS]:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            continue
        try:
            xml_text = _fetch(url)
        except Exception:  # noqa: BLE001
            continue
        for item in _parse_feed(xml_text):
            item["source"] = parsed.netloc
            headlines.append(item)
    return {"items": headlines[:limit]}
